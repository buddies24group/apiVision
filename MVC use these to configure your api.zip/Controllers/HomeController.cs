﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImageResizer;
using ImageToTextAzure.Models;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Configuration;
using System.Threading.Tasks;
using System.IO;
using Microsoft.ProjectOxford.Vision;

namespace ImageToTextAzure.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index2()
        {
            // Pass a list of blob URIs in ViewBag
            CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudBlobClient client = account.CreateCloudBlobClient();
            CloudBlobContainer container = client.GetContainerReference("photos");
            List<BlobInfo> blobs = new List<BlobInfo>();

            //foreach (IListBlobItem item in container.ListBlobs())
            //{
            //    var blob = item as CloudBlockBlob;

            //    if (blob != null)
            //    {
            //        blobs.Add(new BlobInfo()
            //        {
            //            ImageUri = blob.Uri.ToString(),
            //            ThumbnailUri = blob.Uri.ToString().Replace("/photos/", "/thumbnails/")
            //        });
            //    }
            //}
            foreach (IListBlobItem item in container.ListBlobs())
            {
                var blob = item as CloudBlockBlob;

                if (blob != null)
                {
                    blob.FetchAttributes(); // Get blob metadata
                    var caption = blob.Metadata.ContainsKey("Caption") ? blob.Metadata["Caption"] : blob.Name;

                    blobs.Add(new BlobInfo()
                    {
                        ImageUri = blob.Uri.ToString(),
                        ThumbnailUri = blob.Uri.ToString().Replace("/photos/", "/thumbnails/"),
                        Caption = caption
                    });
                }
            }

            ViewBag.Blobs = blobs.ToArray();
            return View();
        }
        public class BlobManager
        {
            private CloudBlobContainer blobContainer;

            public BlobManager(string ContainerName)
            {
                // Check if Container Name is null or empty  
                if (string.IsNullOrEmpty(ContainerName))
                {
                    throw new ArgumentNullException("ContainerName", "Container Name can't be empty");
                }
                try
                {
                    // Get azure table storage connection string.  
                    string ConnectionString = "Your Azure Storage Connection String goes here";
                    CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConnectionString);

                    CloudBlobClient cloudBlobClient = storageAccount.CreateCloudBlobClient();
                    blobContainer = cloudBlobClient.GetContainerReference(ContainerName);

                    // Create the container and set the permission  
                    if (blobContainer.CreateIfNotExists())
                    {
                        blobContainer.SetPermissions(
                            new BlobContainerPermissions
                            {
                                PublicAccess = BlobContainerPublicAccessType.Blob
                            }
                        );
                    }
                }
                catch (Exception ExceptionObj)
                {
                    throw ExceptionObj;
                }
            }
        }
        //public ActionResult Delete(string uri)
        //{
        //    // Container Name - picture  
        //    BlobManager BlobManagerObj = new BlobManager("picture");
        //    BlobManagerObj.DeleteBlob(uri);
        //    return RedirectToAction("Get");
        //}
        public ActionResult DeleteBlob(string uri)
        {
            try
            {
                Uri uriObj = new Uri(uri);
                string BlobName = Path.GetFileName(uriObj.LocalPath);

                // Pass a list of blob URIs and captions in ViewBag
                CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
                CloudBlobClient client = account.CreateCloudBlobClient();
                CloudBlobContainer container = client.GetContainerReference("photos");
                // get block blob refarence  
                CloudBlockBlob blockBlob = container.GetBlockBlobReference(BlobName);

               if(blockBlob!= null)
                {
                    // delete blob from container      
                    blockBlob.Delete();

                    return RedirectToAction("DeleteFromBlob2");
                }
                
            }
            catch (Exception ExceptionObj)
            {
                throw ExceptionObj;
            }
            return RedirectToAction("DeleteFromBlob2");
        }
        public ActionResult DeleteFromBlob2(string id)
        {
            // Pass a list of blob URIs and captions in ViewBag
            CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudBlobClient client = account.CreateCloudBlobClient();
            CloudBlobContainer container = client.GetContainerReference("photos");
            List<BlobInfo> blobs = new List<BlobInfo>();

            foreach (IListBlobItem item in container.ListBlobs())
            {
                var iblob = item as CloudBlockBlob;

                if (iblob != null)
                {
                    iblob.FetchAttributes(); // Get blob metadata

                    if (String.IsNullOrEmpty(id) || HasMatchingMetadata(iblob, id))
                    {
                        var caption = iblob.Metadata.ContainsKey("Caption") ? iblob.Metadata["Caption"] : iblob.Name;

                        blobs.Add(new BlobInfo()
                        {
                            ImageUri = iblob.Uri.ToString(),
                            ThumbnailUri = iblob.Uri.ToString().Replace("/photos/", "/thumbnails/"),
                            Caption = caption
                        });
                    }
                }
            }

            ViewBag.Blobs = blobs.ToArray();
            ViewBag.Search = id; // Prevent search box from losing its content
           //RedirectToAction("Index");
            return View("DeleteFromBlob2");


        }
        public ActionResult Index(string id)
        {
            // Pass a list of blob URIs and captions in ViewBag
            CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudBlobClient client = account.CreateCloudBlobClient();
            CloudBlobContainer container = client.GetContainerReference("photos");
            List<BlobInfo> blobs = new List<BlobInfo>();

            foreach (IListBlobItem item in container.ListBlobs())
            {
                var blob = item as CloudBlockBlob;

                if (blob != null)
                {
                    blob.FetchAttributes(); // Get blob metadata

                    if (String.IsNullOrEmpty(id) || HasMatchingMetadata(blob, id))
                    {
                        var caption = blob.Metadata.ContainsKey("Caption") ? blob.Metadata["Caption"] : blob.Name;

                        blobs.Add(new BlobInfo()
                        {
                            ImageUri = blob.Uri.ToString(),
                            ThumbnailUri = blob.Uri.ToString().Replace("/photos/", "/thumbnails/"),
                            Caption = caption
                        });
                    }
                }
            }

            ViewBag.Blobs = blobs.ToArray();
            ViewBag.Search = id; // Prevent search box from losing its content
            return View();
        }

        private bool HasMatchingMetadata(CloudBlockBlob blob, string term)
        {
            foreach (var item in blob.Metadata)
            {
                if (item.Key.StartsWith("Tag") && item.Value.Equals(term, StringComparison.InvariantCultureIgnoreCase))
                    return true;
            }

            return false;
        }



        [HttpPost]
        public ActionResult Search(string term)
        {
            return RedirectToAction("Index",new{ id =term});
        }

        [HttpPost]
        public ActionResult SearchDel(string term)
        {
            return RedirectToAction("DeleteFromBlob2", new { id = term });
        }
        public ActionResult DeleteFromBlob(string filename)
        {
            // Retrieve storage account from connection string.
            //CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);

            // Create the blob client.
            //CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve reference to a previously created container.
            //CloudBlobContainer container = blobClient.GetContainerReference(containerName);

            // Retrieve reference to a blob named "myblob.csv".
            //CloudBlockBlob blockBlob = container.GetBlockBlobReference(filename);

            CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudBlobClient client = account.CreateCloudBlobClient();
            CloudBlobContainer container = client.GetContainerReference("photos");
            CloudBlockBlob _blockBlob = container.GetBlockBlobReference(filename);

            // Delete the blob.
            if (_blockBlob != null)
            {
                _blockBlob.Delete();
                return RedirectToAction("Index");
            }
            else
            {
                _blockBlob.DeleteIfExists();
                return RedirectToAction("Index");

            }
            //return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<ActionResult> Upload(HttpPostedFileBase file)
        {
            if (file != null && file.ContentLength > 0)
            {
                // Make sure the user selected an image file
                if (!file.ContentType.StartsWith("image"))
                {
                    TempData["Message"] = "Only image files may be uploaded";
                }
                else
                {
                    try
                    {
                        // Save the original image in the "photos" container
                        CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
                        CloudBlobClient client = account.CreateCloudBlobClient();
                        CloudBlobContainer container = client.GetContainerReference("photos");
                        CloudBlockBlob photo = container.GetBlockBlobReference(Path.GetFileName(file.FileName));
                        await photo.UploadFromStreamAsync(file.InputStream);

                        // Generate a thumbnail and save it in the "thumbnails" container
                        using (var outputStream = new MemoryStream())
                        {
                            file.InputStream.Seek(0L, SeekOrigin.Begin);
                            var settings = new ResizeSettings { MaxWidth = 192 };
                            ImageBuilder.Current.Build(file.InputStream, outputStream, settings);
                            outputStream.Seek(0L, SeekOrigin.Begin);
                            container = client.GetContainerReference("thumbnails");
                            CloudBlockBlob thumbnail = container.GetBlockBlobReference(Path.GetFileName(file.FileName));
                            await thumbnail.UploadFromStreamAsync(outputStream);
                        }

                        // Submit the image to Azure's Computer Vision API
                        VisionServiceClient vision = new VisionServiceClient(
                            ConfigurationManager.AppSettings["SubscriptionKey"],
                            ConfigurationManager.AppSettings["VisionEndpoint"]
                        );

                        VisualFeature[] features = new VisualFeature[] { VisualFeature.Description };
                        var result = await vision.AnalyzeImageAsync(photo.Uri.ToString(), features);

                        // Record the image description and tags in blob metadata
                        photo.Metadata.Add("Caption", result.Description.Captions[0].Text);

                        for (int i = 0; i < result.Description.Tags.Length; i++)
                        {
                            string key = String.Format("Tag{0}", i);
                            photo.Metadata.Add(key, result.Description.Tags[i]);
                        }

                        await photo.SetMetadataAsync();
                    }
                    catch (Exception ex)
                    {
                        // In case something goes wrong
                        TempData["Message"] = ex.Message;
                    }
                }
            }

            return RedirectToAction("Index");
        }

        public ActionResult getPropeties(string name)
        {
            Uri uri = new Uri(name);
            CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudBlobClient client = account.CreateCloudBlobClient();
            CloudBlobContainer container = client.GetContainerReference("photos");
            string filename = System.IO.Path.GetFileName(uri.LocalPath);

            var blob = container.GetBlockBlobReference(filename);
            String URL = blob.Uri.AbsolutePath.ToString();

            blob.FetchAttributes();
            ViewBag.URL = uri.ToString();
            ViewBag.blobname = blob.Name;
            ViewBag.Legnth = blob.Properties.Length;
            ViewBag.BlobType = blob.BlobType;
            ViewBag.ETag = blob.Properties.ETag;
            ViewBag.Created = blob.Properties.Created;
            ViewBag.LastModified = blob.Properties.LastModified;

            return View();
        }




        public ActionResult HomePage()
        {
          

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}